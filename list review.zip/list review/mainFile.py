# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 13:24:29 2024

@author: seidih6290
"""
import functions as fn
def main():
    test_nums =int(input("Enter number of tests: "))
    
    # ask user to enter names,
    # create a list with test names
    tests = []
    
    for x in range(test_nums):
        
        test_name = input("Enter test name: ")
        
        tests.append(test_name)
    
    
    
    # ask for # of students
    stu_nums = int(input("Enter num of students: "))
    
    
    students = []
    for x in range(stu_nums):
        student = []
        stu_name = input("Enter student name: ")
        student.append(stu_name)
        
        # enter score for each test
        for test in tests:
            
            print("Enter score for", test)
            
            score = float(input())
            student.append(score)
        scores = student[1:]
        # get avg
        avg = sum(scores)/len(scores)
        # append to student list
        student.append(avg)
        
        # get letter grade
        grade = fn.get_letgrade(avg)
        
        #grade = "A"
        # add to list
        
        student.append(grade)
        students.append(student)

        
        

if __name__ =="__main__":
    
    main()