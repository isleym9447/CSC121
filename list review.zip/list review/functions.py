# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


def get_letgrade(score):
    
    if score >= 90:
        
        grade = "A"
    elif score >= 80:
        
        grade = "B"
    elif score >= 70:
        
        grade = "C"
    elif score >= 60:
        
        grade = "D"
    else:
        
        grade = "F"
    return grade
    
    
